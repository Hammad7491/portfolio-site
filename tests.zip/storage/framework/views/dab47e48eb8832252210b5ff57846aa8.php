
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('indexes.section1', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
this is about

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/pages/about.blade.php ENDPATH**/ ?>