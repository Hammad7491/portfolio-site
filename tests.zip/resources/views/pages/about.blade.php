@extends('layouts.app')
@section('content')

@include('indexes.section1')
this is about

@endsection