@extends('layouts.app')
@section('content')

@include('indexes.section1')
@include('indexes.section2')
@include('indexes.section3')
@include('indexes.section4')
@include('indexes.section5')
@include('indexes.section6')
@include('indexes.section7')
@include('indexes.section8')
@include('indexes.section9')
@include('indexes.section10')
@include('indexes.section11')
@include('indexes.section12')
@include('indexes.section13')


@endsection